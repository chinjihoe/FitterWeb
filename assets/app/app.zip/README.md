# Fitter

To do:

Tab 1

Weight textbox text should say weight or distance depending on exercise
Optional notes
Picture/clip of exercise

Tab 2

Pictures/clips of all exercises

Tab 3

Light/dark mode